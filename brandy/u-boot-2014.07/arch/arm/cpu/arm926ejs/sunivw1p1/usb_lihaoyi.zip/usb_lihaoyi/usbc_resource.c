/*
 * (C) Copyright 2007-2013
 * Allwinner Technology Co., Ltd. <www.allwinnertech.com>
 * Jerry Wang <wangflord@allwinnertech.com>
 *
 * See file CREDITS for list of people who contributed to this
 * project.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	 See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 * MA 02111-1307 USA
 */

#include  "usbc_i.h"
#if 1
#define get_wvalue(addr)	(*((volatile unsigned long  *)(addr)))
#define put_wvalue(addr, v)	(*((volatile unsigned long  *)(addr)) = (unsigned long)(v))

void usb_phy_config()
{
	 u32 reg_val=0;
	 u32 i;
	 u32 value;

	 reg_val = get_wvalue(SUNXI_CCM_BASE + 0x2c0);
	 reg_val &= ~(0x01<<24);
	 put_wvalue(SUNXI_CCM_BASE + 0x2c0, reg_val);
	 reg_val = get_wvalue(SUNXI_CCM_BASE + 0x60);
	 reg_val &= ~(0x01<<24);
	 put_wvalue(SUNXI_CCM_BASE + 0x60, reg_val);
	 for(i=0; i<10000;i++);

	 //USB PHY Config
	 reg_val = get_wvalue(SUNXI_CCM_BASE + 0xCC);
	 reg_val &= ~(0x01<<0);
#ifndef FPGA_PLATFORM
	 reg_val |= (0x01<<1); //Special Clock Gating
#endif
	 put_wvalue(SUNXI_CCM_BASE + 0xCC, reg_val);
	 for(i=0; i<10000;i++);
	 reg_val = get_wvalue(SUNXI_CCM_BASE + 0xCC);
	 reg_val |= (0x03<<0); //Phy Reset
	 put_wvalue(SUNXI_CCM_BASE + 0xCC, reg_val);
	 for(i=0; i<10000;i++);

	debug("0xcc = %x\n",get_wvalue(SUNXI_CCM_BASE + 0xCC));
	 for(i=0; i<10000;i++);

	 //USB SIE Config
	 reg_val = get_wvalue(SUNXI_CCM_BASE + 0x60);
	 reg_val |= (0x01<<24);
	 put_wvalue(SUNXI_CCM_BASE + 0x60, reg_val);
	for(i=0; i<10000;i++);	
	 reg_val = get_wvalue(SUNXI_CCM_BASE + 0x2c0);
	 reg_val |= (0x01<<24);
	 put_wvalue(SUNXI_CCM_BASE + 0x2c0, reg_val);
	 for(i=0; i<10; i++);
  

}

unsigned int  hcd_open_clk(void)

{
	usb_phy_config();
	return 0;


}

#endif

/*
*******************************************************************************
*                     usb_open_clock
*
* Description:
*    void
*
* Parameters:
*    void
*
* Return value:
*    void
*
* note:
*    void
*
*******************************************************************************
*/
int usb_open_clock(void)
{
    u32 reg_value = 0;

	//return hcd_open_clk();
	//Enable module clock for USB phy0
	reg_value = readl(SUNXI_CCM_BASE + 0xcc);
	reg_value |= (1 << 0) | (1 << 1);
	writel(reg_value, (SUNXI_CCM_BASE + 0xcc));
	//delay some time
	__msdelay(10);

    //Gating AHB clock for USB_phy0
	reg_value = readl(SUNXI_CCM_BASE + 0x60);
	reg_value |= (1 << 24);
	writel(reg_value, (SUNXI_CCM_BASE + 0x60));

    //delay to wati SIE stable
	__msdelay(10);

    /* AHB reset */
    reg_value = readl(SUNXI_CCM_BASE + 0x2C0);
    reg_value |= (1 << 24);
    writel(reg_value, (SUNXI_CCM_BASE + 0x2C0));
    __msdelay(10);

    //restart a session
    __msdelay(10);

	return 0;
}
/*
*******************************************************************************
*                     usb_op_clock
*
* Description:
*    void
*
* Parameters:
*    void
*
* Return value:
*    void
*
* note:
*    void
*
*******************************************************************************
*/
int usb_close_clock(void)
{
    u32 reg_value = 0;

	//��USB phyʱ��
	reg_value = readl(SUNXI_CCM_BASE + 0xcc);
	reg_value &= ~((1 << 0) | (1 << 1));
	writel(reg_value, (SUNXI_CCM_BASE + 0xcc));
	__msdelay(10);

    /* AHB reset */
    reg_value = readl(SUNXI_CCM_BASE + 0x2C0);
    reg_value &= ~(1 << 24);
    writel(reg_value, (SUNXI_CCM_BASE + 0x2C0));
    __msdelay(10);

    //��usb ahbʱ��
	reg_value = readl(SUNXI_CCM_BASE + 0x60);
	reg_value &= ~(1 << 24);
	writel(reg_value, (SUNXI_CCM_BASE + 0x60));
    //��sie��ʱ�ӱ���
	__msdelay(10);

	return 0;
}


